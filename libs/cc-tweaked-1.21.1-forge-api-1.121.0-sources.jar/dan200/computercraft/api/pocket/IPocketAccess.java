// SPDX-FileCopyrightText: 2017 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package dan200.computercraft.api.pocket;

import dan200.computercraft.api.upgrades.UpgradeBase;
import dan200.computercraft.api.upgrades.UpgradeData;
import dan200.computercraft.api.upgrades.UpgradeHandle;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;

/**
 * Wrapper class for pocket computers.
 */
@ApiStatus.NonExtendable
public interface IPocketAccess {
    /**
     * Get the level in which the pocket computer exists.
     *
     * @return The pocket computer's level.
     */
    ServerLevel getLevel();

    /**
     * Get the position of the pocket computer.
     *
     * @return The pocket computer's position.
     */
    Vec3 getPosition();

    /**
     * Gets the entity holding this item.
     * <p>
     * This must be called on the server thread.
     *
     * @return The holding entity, or {@code null} if none exists.
     */
    @Nullable
    Entity getEntity();

    /**
     * Get the colour of this pocket computer as a RGB number.
     *
     * @return The colour this pocket computer is. This will be a RGB colour between {@code 0x000000} and
     * {@code 0xFFFFFF} or -1 if it has no colour.
     * @see #setColour(int)
     */
    int getColour();

    /**
     * Set the colour of the pocket computer to a RGB number.
     *
     * @param colour The colour this pocket computer should be changed to. This should be a RGB colour between
     *               {@code 0x000000} and {@code 0xFFFFFF} or -1 to reset to the default colour.
     * @see #getColour()
     */
    void setColour(int colour);

    /**
     * Get the colour of this pocket computer's light as a RGB number.
     *
     * @return The colour this light is. This will be a RGB colour between {@code 0x000000} and {@code 0xFFFFFF} or
     * -1 if it has no colour.
     * @see #setLight(int)
     */
    int getLight();

    /**
     * Set the colour of the pocket computer's light to a RGB number.
     *
     * @param colour The colour this modem's light will be changed to. This should be a RGB colour between
     *               {@code 0x000000} and {@code 0xFFFFFF} or -1 to reset to the default colour.
     * @see #getLight()
     */
    void setLight(int colour);

    /**
     * Get the currently equipped upgrade.
     *
     * @return The currently equipped upgrade.
     * @see #setUpgrade(UpgradeData)
     * @see #getUpgradeHandle()
     */
    @Nullable UpgradeData<IPocketUpgrade> getUpgrade();

    /**
     * Get a handle to the equipped upgrade.
     * <p>
     * This function is not thread safe and must be called from the server thread.
     *
     * @return The currently equipped upgrade.
     * @see #setUpgrade(UpgradeData)
     * @since 1.121.0
     */
    @Nullable UpgradeHandle<IPocketUpgrade> getUpgradeHandle();

    /**
     * Set the upgrade for this pocket computer, also updating the item stack.
     * <p>
     * This function is not thread safe and must be called from the server thread.
     *
     * @param upgrade The new upgrade to set it to, may be {@code null}.
     * @see #getUpgrade()
     * @see #getUpgradeHandle()
     */
    void setUpgrade(@Nullable UpgradeData<IPocketUpgrade> upgrade);

    /**
     * Get the upgrade-specific NBT.
     * <p>
     * This is persisted between computer reboots and chunk loads.
     *
     * @return The upgrade's NBT.
     * @see #setUpgradeData(DataComponentPatch)
     * @see UpgradeBase#getUpgradeItem(DataComponentPatch)
     * @see UpgradeBase#getUpgradeData(ItemStack)
     * @see #getUpgrade()
     * @deprecated Use {@link #getUpgradeHandle()} and {@link UpgradeHandle#getData()}.
     */
    @Deprecated(since = "1.121.0")
    DataComponentPatch getUpgradeData();

    /**
     * Update the upgrade-specific data.
     *
     * @param data The new upgrade data.
     * @see #getUpgradeData()
     * @deprecated Use {@link #getUpgradeHandle()} and {@link UpgradeHandle#setData(DataComponentPatch)}.
     */
    @Deprecated(since = "1.121.0")
    void setUpgradeData(DataComponentPatch data);

    /**
     * Remove the current peripheral and create a new one.
     * <p>
     * You may wish to do this if the methods available change, for instance when the {@linkplain #getEntity() owning
     * entity} changes.
     */
    void invalidatePeripheral();
}
